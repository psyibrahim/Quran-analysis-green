<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/6a50a695-0d46-4b69-968e-95e34ea8990a

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## الخطوط

| الموضع | الخط |
|---|---|
| نص القرآن (حفص) | KFGQPC Uthmanic Hafs — `public/fonts/KFGQPC-Uthmanic-Hafs.woff2` |
| نص القرآن (ورش) | KFGQPC Warsh — `public/fonts/KFGQPC-Warsh.woff2` |
| بديل نص القرآن | Amiri Quran / Scheherazade New (Google Fonts) |
| العناوين وأسماء السور | Amiri (`.font-heading`) — وMarkazi Text محمّل ويمكن تفعيله بتغيير `--font-heading` في `src/index.css` |
| الواجهة والأزرار | IBM Plex Sans Arabic / Noto Sans Arabic |
| الأرقام والإحصاءات | IBM Plex Mono (`font-mono`) |

الخط النشط لنص القرآن يتبدّل تلقائياً عبر `data-riwaya` على `<html>`؛ ولتثبيت رواية معيّنة استعمل `.font-quran-hafs` أو `.font-quran-warsh`.
خطوط KFGQPC © مجمع الملك فهد لطباعة المصحف الشريف.
